from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine
from dotenv import load_dotenv
import os

load_dotenv()

password= os.environ.get('DATABASE_PASSWORD')
host= os.environ.get("DATABASE_HOST", "localhost")
database= os.environ.get("DATABASE_NAME", "cashcow_dev_2478")
username= os.environ.get("DATABSE_USERNAME", "postgres")
port= os.environ.get("DATABSE_PORT", "5432")

DATABASE_URL = (
    f"postgresql+asyncpg://{username}:{password}"
    f"@{host}:{port}/{database}"
)
engine= create_async_engine(DATABASE_URL, echo= False)

AsyncSessionLocal= async_sessionmaker(engine, expire_on_commit= False)
